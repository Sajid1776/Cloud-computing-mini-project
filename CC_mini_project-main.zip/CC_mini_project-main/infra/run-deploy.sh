#!/usr/bin/env bash
# Add AWS CLI to PATH for Git Bash
export PATH="/c/Program Files/Amazon/AWSCLIV2:$PATH"

export SITE_BUCKET=loud-block-vault-site-12345
export AWS_REGION=us-east-1

# Navigate to project root (one level up from infra/)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
export SITE_DIR="$PROJECT_ROOT/site"

cd "$PROJECT_ROOT"

set -euo pipefail

CALLER_REF="cbv-site-$(date +%s)"
# Create temp dir under Windows TEMP so the native AWS CLI can access it
TMP_DIR=$(mktemp -d --tmpdir="$(cmd.exe /c 'echo %TEMP%' 2>/dev/null | tr -d '\r\n' || echo /tmp)")
trap 'rm -rf "$TMP_DIR"' EXIT
# Windows-style path for AWS CLI file:// references
WIN_TMP_DIR=$(echo "$TMP_DIR" | sed 's|/\([a-z]\)/|\1:/|; s|/|\\|g')

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
echo "==> Account: $ACCOUNT_ID  Region: $AWS_REGION  Bucket: $SITE_BUCKET"

echo "==> 1/5 Bucket already created manually — skipping creation"

echo "==> 2/5 Blocking all public access"
aws s3api put-public-access-block --bucket "$SITE_BUCKET" \
  --public-access-block-configuration \
  BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true

echo "==> 3/5 Syncing $SITE_DIR/ to s3://$SITE_BUCKET"
aws s3 sync "$SITE_DIR" "s3://$SITE_BUCKET" --delete

echo "==> 4/5 Reusing existing Origin Access Control (E1BK6ZKCY1QOHD)"
OAC_ID="E1BK6ZKCY1QOHD"

ORIGIN_DOMAIN="${SITE_BUCKET}.s3.amazonaws.com"

cat > "$TMP_DIR/dist.json" <<EOF
{
  "CallerReference": "${CALLER_REF}",
  "Comment": "Cloud Block Vault docs site",
  "Enabled": true,
  "DefaultRootObject": "index.html",
  "Origins": {
    "Quantity": 1,
    "Items": [
      {
        "Id": "s3-origin",
        "DomainName": "${ORIGIN_DOMAIN}",
        "OriginAccessControlId": "${OAC_ID}",
        "S3OriginConfig": { "OriginAccessIdentity": "" }
      }
    ]
  },
  "DefaultCacheBehavior": {
    "TargetOriginId": "s3-origin",
    "ViewerProtocolPolicy": "redirect-to-https",
    "AllowedMethods": { "Quantity": 2, "Items": ["GET", "HEAD"], "CachedMethods": { "Quantity": 2, "Items": ["GET", "HEAD"] } },
    "ForwardedValues": { "QueryString": false, "Cookies": { "Forward": "none" } },
    "SmoothStreaming": false,
    "Compress": true,
    "CachePolicyId": "658327ea-f89d-4fab-a63d-7e88639e58f6"
  },
  "PriceClass": "PriceClass_100",
  "ViewerCertificate": { "CloudFrontDefaultCertificate": true },
  "HttpVersion": "http2and3"
}
EOF

echo "==> 5/5 Creating CloudFront distribution (takes ~5 minutes to deploy)"
DIST_JSON=$(aws cloudfront create-distribution --distribution-config "file://$WIN_TMP_DIR\dist.json")
DIST_ID=$(echo "$DIST_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)["Distribution"]["Id"])' 2>/dev/null \
  || echo "$DIST_JSON" | grep -o '"Id": *"[^"]*"' | head -1 | sed 's/.*"Id": *"//; s/"//')
DIST_DOMAIN=$(echo "$DIST_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)["Distribution"]["DomainName"])' 2>/dev/null \
  || echo "$DIST_JSON" | grep -o '"DomainName": *"[^"]*"' | head -1 | sed 's/.*"DomainName": *"//; s/"//')

cat > "$TMP_DIR/policy.json" <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowCloudFrontRead",
      "Effect": "Allow",
      "Principal": { "Service": "cloudfront.amazonaws.com" },
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::${SITE_BUCKET}/*",
      "Condition": {
        "StringEquals": { "AWS:SourceArn": "arn:aws:cloudfront::${ACCOUNT_ID}:distribution/${DIST_ID}" }
      }
    }
  ]
}
EOF
aws s3api put-bucket-policy --bucket "$SITE_BUCKET" --policy "file://$WIN_TMP_DIR\policy.json"

echo
echo "Done!"
echo "  Distribution ID : $DIST_ID"
echo "  Site URL        : https://${DIST_DOMAIN}"
echo "  Note: first deployment takes ~5 minutes to propagate globally."
echo "  To invalidate cache later: ./infra/invalidate.sh $DIST_ID"
